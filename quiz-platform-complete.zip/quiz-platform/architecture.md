# Quiz Platform Architecture

## System Overview

The Quiz Platform is a full-stack web application designed to handle real-time MCQ tests for up to 200 concurrent users with advanced anti-cheating features.

## Technology Stack

### Backend
- **Framework**: Flask (Python)
- **Database**: SQLite (with SQLAlchemy ORM)
- **Real-time**: Flask-SocketIO (WebSocket)
- **Authentication**: JWT tokens
- **Image Generation**: PIL (Python Imaging Library)
- **File Upload**: Flask file handling
- **CORS**: Flask-CORS

### Frontend
- **Framework**: React 18
- **Styling**: Tailwind CSS + shadcn/ui
- **Icons**: Lucide React
- **Charts**: Recharts
- **Routing**: React Router DOM
- **Real-time**: Socket.IO Client
- **HTTP Client**: Fetch API

### Deployment
- **Backend**: Flask production server
- **Frontend**: Static build served by Flask
- **Database**: SQLite file-based
- **Images**: Local file storage with caching

## Architecture Patterns

### 1. MVC Pattern (Backend)
- **Models**: SQLAlchemy models for database entities
- **Views**: Flask routes and API endpoints
- **Controllers**: Business logic in service layers

### 2. Component-Based Architecture (Frontend)
- **Pages**: Top-level route components
- **Components**: Reusable UI components
- **Hooks**: Custom React hooks for state management
- **Services**: API communication layer

### 3. Real-time Communication
- **WebSocket**: Bidirectional communication for timers and live updates
- **Event-Driven**: Pub/Sub pattern for real-time features
- **Session Management**: Persistent connections with session validation

## Security Architecture

### Anti-Cheating Measures
1. **Text-to-Image Conversion**
   - All questions and options rendered as images
   - Prevents copy-paste and text selection
   - Watermarked images for brand protection

2. **Session Security**
   - Unique session tokens
   - IP address validation
   - User agent tracking
   - Session timeout handling

3. **Frontend Security**
   - Disabled right-click context menu
   - Disabled text selection
   - Disabled developer tools (basic deterrent)
   - Randomized question and option order

4. **Backend Security**
   - JWT token authentication
   - Rate limiting on API endpoints
   - Input validation and sanitization
   - SQL injection prevention via ORM

## Scalability Considerations

### Database Optimization
- Indexed foreign keys for fast joins
- Composite indexes for common queries
- Connection pooling for concurrent access
- Query optimization for large datasets

### Performance Features
- **Image Caching**: Generated images cached on disk
- **Session Pooling**: Efficient WebSocket connection management
- **Lazy Loading**: Questions loaded on-demand
- **Compression**: Gzip compression for API responses

### Concurrent User Handling
- **Async Processing**: Non-blocking I/O operations
- **Connection Limits**: Managed WebSocket connections
- **Resource Monitoring**: Memory and CPU usage tracking
- **Graceful Degradation**: Fallback mechanisms for high load

## Data Flow

### Quiz Taking Flow
1. User authenticates and selects quiz
2. Backend creates session and generates question images
3. Frontend establishes WebSocket connection
4. Real-time timer synchronization begins
5. User answers questions (stored immediately)
6. Backend calculates scores with time bonuses
7. Results displayed with detailed analytics

### Admin Flow
1. Admin uploads questions (CSV/Excel or manual)
2. Backend processes and generates question images
3. Quiz configuration and scheduling
4. Real-time monitoring of active sessions
5. Analytics and reporting dashboard

## File Structure

```
quiz-platform/
├── quiz-backend/
│   ├── src/
│   │   ├── models/          # Database models
│   │   ├── routes/          # API endpoints
│   │   ├── services/        # Business logic
│   │   ├── utils/           # Helper functions
│   │   ├── static/          # Frontend build + images
│   │   └── main.py          # Application entry point
│   ├── requirements.txt
│   └── venv/
├── quiz-frontend/
│   ├── src/
│   │   ├── components/      # React components
│   │   ├── pages/           # Route components
│   │   ├── hooks/           # Custom hooks
│   │   ├── services/        # API services
│   │   └── utils/           # Helper functions
│   ├── public/
│   └── package.json
├── database_schema.md
├── api_design.md
└── architecture.md
```

## Deployment Strategy

### Development
- Backend: Flask development server
- Frontend: Vite development server
- Database: Local SQLite file

### Production
- Backend: Flask production server (Gunicorn)
- Frontend: Built static files served by Flask
- Database: SQLite with backup strategy
- Images: Local storage with CDN option

## Monitoring and Analytics

### Real-time Metrics
- Active user count
- Session completion rates
- Average response times
- Error rates and types

### Quiz Analytics
- Question difficulty analysis
- Time-based performance metrics
- User behavior patterns
- Cheating attempt detection

## Error Handling

### Backend Error Handling
- Structured error responses
- Logging with different levels
- Graceful degradation for failures
- Database transaction rollbacks

### Frontend Error Handling
- Error boundaries for React components
- User-friendly error messages
- Retry mechanisms for failed requests
- Offline state handling

## Future Enhancements

### Scalability Improvements
- Redis for session storage
- PostgreSQL for better concurrency
- Load balancing for multiple instances
- CDN for image delivery

### Feature Additions
- Video questions support
- Advanced analytics dashboard
- Mobile app development
- Integration with LMS platforms

