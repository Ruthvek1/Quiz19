# Quiz Platform Database Schema

## Tables Overview

### 1. Users Table
- **Purpose**: Store user information and authentication
- **Fields**:
  - `id` (Primary Key)
  - `username` (Unique)
  - `email` (Unique)
  - `password_hash`
  - `role` (admin/user)
  - `created_at`
  - `is_active`

### 2. Quizzes Table
- **Purpose**: Store quiz metadata and configuration
- **Fields**:
  - `id` (Primary Key)
  - `title`
  - `description`
  - `duration_minutes` (Global timer)
  - `per_question_time_seconds` (Optional per-question timer)
  - `total_questions`
  - `randomize_questions` (Boolean)
  - `randomize_options` (Boolean)
  - `created_by` (Foreign Key to Users)
  - `created_at`
  - `is_active`
  - `start_time` (When quiz becomes available)
  - `end_time` (When quiz closes)

### 3. Questions Table
- **Purpose**: Store individual quiz questions
- **Fields**:
  - `id` (Primary Key)
  - `quiz_id` (Foreign Key to Quizzes)
  - `question_text`
  - `question_image_path` (Generated image path)
  - `option_a`
  - `option_b`
  - `option_c`
  - `option_d`
  - `options_image_path` (Generated image path for options)
  - `correct_answer` (a/b/c/d)
  - `question_order` (Display order)
  - `time_bonus_factor` (Multiplier for time bonus)

### 4. User_Sessions Table
- **Purpose**: Track active quiz sessions
- **Fields**:
  - `id` (Primary Key)
  - `user_id` (Foreign Key to Users)
  - `quiz_id` (Foreign Key to Quizzes)
  - `session_token` (Unique session identifier)
  - `start_time`
  - `end_time`
  - `current_question_index`
  - `time_remaining`
  - `is_completed`
  - `ip_address`
  - `user_agent`

### 5. User_Answers Table
- **Purpose**: Store user responses to questions
- **Fields**:
  - `id` (Primary Key)
  - `session_id` (Foreign Key to User_Sessions)
  - `question_id` (Foreign Key to Questions)
  - `selected_answer` (a/b/c/d or null if unanswered)
  - `time_taken_seconds`
  - `answered_at`
  - `is_correct` (Boolean)

### 6. Quiz_Results Table
- **Purpose**: Store final quiz results and scores
- **Fields**:
  - `id` (Primary Key)
  - `session_id` (Foreign Key to User_Sessions)
  - `user_id` (Foreign Key to Users)
  - `quiz_id` (Foreign Key to Quizzes)
  - `total_score`
  - `accuracy_score` (Correct answers count)
  - `time_bonus_score`
  - `total_time_taken`
  - `questions_attempted`
  - `questions_correct`
  - `completion_percentage`
  - `submitted_at`

### 7. Admin_Logs Table
- **Purpose**: Track admin actions for auditing
- **Fields**:
  - `id` (Primary Key)
  - `admin_id` (Foreign Key to Users)
  - `action` (create_quiz, delete_quiz, etc.)
  - `target_id` (ID of affected resource)
  - `details` (JSON field with action details)
  - `timestamp`

## Relationships

1. **Users → Quizzes**: One-to-Many (Creator relationship)
2. **Quizzes → Questions**: One-to-Many
3. **Users → User_Sessions**: One-to-Many
4. **Quizzes → User_Sessions**: One-to-Many
5. **User_Sessions → User_Answers**: One-to-Many
6. **Questions → User_Answers**: One-to-Many
7. **User_Sessions → Quiz_Results**: One-to-One

## Indexes for Performance

- `user_sessions.user_id, quiz_id` (Composite index)
- `user_answers.session_id`
- `questions.quiz_id`
- `quiz_results.user_id, quiz_id` (Composite index)

## Security Considerations

- Password hashing using bcrypt
- Session tokens using secure random generation
- IP address logging for session validation
- Soft deletes for data retention

