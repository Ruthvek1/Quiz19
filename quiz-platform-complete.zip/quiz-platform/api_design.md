# Quiz Platform API Design

## REST API Endpoints

### Authentication Endpoints
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout
- `GET /api/auth/me` - Get current user info

### Quiz Management (Admin)
- `GET /api/admin/quizzes` - List all quizzes
- `POST /api/admin/quizzes` - Create new quiz
- `GET /api/admin/quizzes/{id}` - Get quiz details
- `PUT /api/admin/quizzes/{id}` - Update quiz
- `DELETE /api/admin/quizzes/{id}` - Delete quiz
- `POST /api/admin/quizzes/{id}/questions` - Add questions to quiz
- `POST /api/admin/quizzes/{id}/upload` - Bulk upload questions (CSV/Excel)

### Question Management (Admin)
- `GET /api/admin/questions/{quiz_id}` - Get questions for quiz
- `POST /api/admin/questions` - Create single question
- `PUT /api/admin/questions/{id}` - Update question
- `DELETE /api/admin/questions/{id}` - Delete question
- `POST /api/admin/questions/{id}/generate-image` - Generate question image

### User Quiz Endpoints
- `GET /api/quizzes` - List available quizzes for user
- `GET /api/quizzes/{id}` - Get quiz info (without questions)
- `POST /api/quizzes/{id}/start` - Start quiz session
- `GET /api/sessions/{session_id}` - Get current session info
- `GET /api/sessions/{session_id}/question` - Get current question (as image)
- `POST /api/sessions/{session_id}/answer` - Submit answer
- `POST /api/sessions/{session_id}/next` - Move to next question
- `POST /api/sessions/{session_id}/previous` - Move to previous question
- `POST /api/sessions/{session_id}/submit` - Submit entire quiz
- `GET /api/sessions/{session_id}/result` - Get quiz result

### Monitoring Endpoints (Admin)
- `GET /api/admin/sessions/active` - Get active sessions
- `GET /api/admin/sessions/{session_id}` - Get session details
- `GET /api/admin/analytics/{quiz_id}` - Get quiz analytics
- `GET /api/admin/users/online` - Get online users count

### Image Generation Endpoints
- `POST /api/images/question` - Generate question image
- `POST /api/images/options` - Generate options image
- `GET /api/images/{filename}` - Serve generated images

## WebSocket Events

### Client → Server Events

#### Session Management
- `join_session` - Join quiz session
  ```json
  {
    "session_id": "string",
    "user_id": "number"
  }
  ```

- `leave_session` - Leave quiz session
  ```json
  {
    "session_id": "string"
  }
  ```

#### Quiz Interaction
- `answer_question` - Submit answer in real-time
  ```json
  {
    "session_id": "string",
    "question_id": "number",
    "answer": "a|b|c|d",
    "time_taken": "number"
  }
  ```

- `request_time_sync` - Request timer synchronization
  ```json
  {
    "session_id": "string"
  }
  ```

#### Admin Events
- `monitor_session` - Admin monitoring specific session
  ```json
  {
    "session_id": "string",
    "admin_id": "number"
  }
  ```

### Server → Client Events

#### Timer Events
- `timer_update` - Global timer update
  ```json
  {
    "time_remaining": "number",
    "quiz_id": "number"
  }
  ```

- `question_timer_update` - Per-question timer
  ```json
  {
    "time_remaining": "number",
    "question_id": "number",
    "auto_advance": "boolean"
  }
  ```

- `timer_expired` - Timer has expired
  ```json
  {
    "type": "global|question",
    "force_submit": "boolean"
  }
  ```

#### Session Events
- `session_started` - Quiz session started
  ```json
  {
    "session_id": "string",
    "start_time": "timestamp",
    "total_questions": "number"
  }
  ```

- `question_changed` - Current question changed
  ```json
  {
    "question_index": "number",
    "question_id": "number",
    "has_previous": "boolean",
    "has_next": "boolean"
  }
  ```

- `answer_recorded` - Answer was recorded
  ```json
  {
    "question_id": "number",
    "success": "boolean",
    "message": "string"
  }
  ```

- `quiz_completed` - Quiz was completed
  ```json
  {
    "session_id": "string",
    "final_score": "number",
    "redirect_url": "string"
  }
  ```

#### Admin Events
- `user_joined` - User joined quiz
  ```json
  {
    "user_id": "number",
    "username": "string",
    "session_id": "string",
    "timestamp": "timestamp"
  }
  ```

- `user_answered` - User answered question
  ```json
  {
    "user_id": "number",
    "question_id": "number",
    "answer": "string",
    "is_correct": "boolean",
    "time_taken": "number"
  }
  ```

- `session_stats` - Real-time session statistics
  ```json
  {
    "active_users": "number",
    "completed_users": "number",
    "average_score": "number",
    "completion_rate": "number"
  }
  ```

#### Error Events
- `error` - General error message
  ```json
  {
    "code": "string",
    "message": "string",
    "details": "object"
  }
  ```

- `session_invalid` - Session is invalid/expired
  ```json
  {
    "session_id": "string",
    "reason": "string"
  }
  ```

## Response Formats

### Success Response
```json
{
  "success": true,
  "data": {},
  "message": "string"
}
```

### Error Response
```json
{
  "success": false,
  "error": {
    "code": "string",
    "message": "string",
    "details": {}
  }
}
```

## Authentication
- JWT tokens for API authentication
- Session-based authentication for WebSocket connections
- Admin role verification for admin endpoints

## Rate Limiting
- API endpoints: 100 requests per minute per user
- WebSocket events: 50 events per minute per session
- Image generation: 10 requests per minute per user

## Security Headers
- CORS enabled for frontend domain
- Content Security Policy for image serving
- Rate limiting on sensitive endpoints

