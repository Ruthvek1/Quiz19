# Quiz Platform User Manual

## 📚 Table of Contents
1. [Getting Started](#getting-started)
2. [Admin Guide](#admin-guide)
3. [User Guide](#user-guide)
4. [Features Overview](#features-overview)
5. [Security Features](#security-features)
6. [Troubleshooting](#troubleshooting)

## 🚀 Getting Started

### System Requirements
- **Modern web browser** (Chrome, Firefox, Safari, Edge)
- **Stable internet connection**
- **JavaScript enabled**
- **Minimum screen resolution**: 1024x768

### First Time Setup

1. **Access the platform** at your deployed URL
2. **Default admin credentials**:
   - Username: `admin`
   - Password: `admin123`
3. **Change default password** immediately after first login

## 👨‍💼 Admin Guide

### Dashboard Overview

The admin dashboard provides a comprehensive view of your quiz platform:

- **Statistics Cards**: Total users, quizzes, sessions, and average scores
- **Recent Quizzes**: Latest created quizzes with quick actions
- **System Status**: Platform health and active user count
- **Quick Actions**: Common administrative tasks

### Creating Quizzes

#### Method 1: Manual Creation

1. **Navigate to Admin → Create Quiz**
2. **Fill in quiz details**:
   - Title (required)
   - Description
   - Duration in minutes
   - Per-question time limit (optional)
   - Randomization settings

3. **Add questions**:
   - Question text
   - Four multiple choice options (A, B, C, D)
   - Correct answer selection
   - Click "Add Question" to include more

4. **Configure settings**:
   - **Randomize Questions**: Shuffle question order per user
   - **Randomize Options**: Shuffle answer options per user
   - **Time Limits**: Global and per-question timing

5. **Save and activate** the quiz

#### Method 2: Bulk Upload (CSV/Excel)

1. **Prepare your file** with columns:
   ```
   question_text,option_a,option_b,option_c,option_d,correct_answer
   ```

2. **Upload via Admin → Bulk Upload**
3. **Review and confirm** imported questions
4. **Set quiz metadata** and activate

### Managing Users

#### User Overview
- **View all registered users**
- **Monitor user activity**
- **Manage user roles** (admin/user)
- **Deactivate problematic accounts**

#### User Analytics
- **Quiz participation rates**
- **Performance statistics**
- **Time spent per quiz**
- **Completion rates**

### Quiz Analytics

#### Performance Metrics
- **Average scores** per quiz
- **Question difficulty analysis**
- **Time spent per question**
- **Completion rates**

#### Reports
- **Export results** to CSV/Excel
- **Generate performance reports**
- **Track user progress over time**

### System Settings

#### Security Configuration
- **Enable/disable anti-cheating features**
- **Set violation thresholds**
- **Configure session timeouts**

#### Platform Settings
- **Customize branding**
- **Set default quiz settings**
- **Configure email notifications**

## 👨‍🎓 User Guide

### Registration and Login

1. **Create an account**:
   - Click "Sign up here" on login page
   - Provide username, email, and password
   - Verify email if required

2. **Login**:
   - Enter username/email and password
   - Click "Sign In"

### Taking Quizzes

#### Starting a Quiz

1. **Browse available quizzes** on dashboard
2. **Click "Start Quiz"** on desired quiz
3. **Review quiz information**:
   - Duration
   - Number of questions
   - Instructions

4. **Click "Begin Quiz"** to start

#### During the Quiz

##### Interface Elements
- **Timer**: Shows remaining time (top right)
- **Progress bar**: Shows completion percentage
- **Question counter**: Current question number
- **Navigation**: Previous/Next buttons

##### Answering Questions
1. **Read the question** (displayed as image for security)
2. **View answer options** (A, B, C, D)
3. **Click your chosen answer**
4. **Navigate** using Previous/Next buttons
5. **Review answers** using question navigation panel

##### Security Features Active
- **Right-click disabled**
- **Text selection prevented**
- **Copy/paste blocked**
- **Tab switching monitored**
- **Developer tools blocked**

#### Finishing the Quiz

1. **Review all answers** using navigation panel
2. **Click "Finish Quiz"** when ready
3. **Confirm submission** in popup dialog
4. **View results** immediately

### Viewing Results

#### Result Page Shows
- **Final score** (accuracy + time bonus)
- **Time taken** vs. allocated time
- **Questions attempted** vs. total
- **Percentage score**
- **Ranking** (if enabled)

#### Score Calculation
- **Base score**: +1 point per correct answer
- **Time bonus**: +0.1 point per second saved
- **No negative marking** for wrong answers

### Profile Management

#### Update Profile
- **Change password**
- **Update email address**
- **View quiz history**
- **Download certificates** (if available)

## 🎯 Features Overview

### Core Features

#### For Administrators
- **Complete quiz management**
- **User monitoring and analytics**
- **Bulk question import/export**
- **Real-time dashboard**
- **Security monitoring**

#### For Users
- **Intuitive quiz interface**
- **Real-time timer**
- **Progress tracking**
- **Instant results**
- **Performance history**

### Advanced Features

#### Anti-Cheating System
- **Image-based questions** prevent text copying
- **Question randomization** per user
- **Option shuffling** for each attempt
- **Tab switching detection**
- **Comprehensive browser restrictions**

#### Real-Time Features
- **Live timer synchronization**
- **Connection status monitoring**
- **Instant answer submission**
- **Real-time user tracking**

#### Scoring System
- **Accuracy-based scoring**
- **Time bonus calculations**
- **Detailed analytics**
- **Performance tracking**

## 🛡️ Security Features

### Anti-Cheating Measures

#### Browser Restrictions
- **Right-click context menu disabled**
- **Text selection prevented**
- **Keyboard shortcuts blocked**:
  - F12 (Developer Tools)
  - Ctrl+U (View Source)
  - Ctrl+C/V/X (Copy/Paste/Cut)
  - Ctrl+A (Select All)
  - Ctrl+P (Print)

#### Content Protection
- **Questions rendered as images**
- **Options displayed as images**
- **Watermarks on generated images**
- **Image drag/save prevention**

#### Session Monitoring
- **Tab switching detection**
- **Window focus monitoring**
- **Connection status tracking**
- **Violation counting and warnings**

#### Question Security
- **Randomized question order**
- **Shuffled answer options**
- **User-specific randomization**
- **Consistent seeding per user**

### Data Security
- **JWT token authentication**
- **Secure session management**
- **HTTPS encryption** (in production)
- **Input validation and sanitization**

## 🔧 Troubleshooting

### Common Issues

#### Login Problems
**Issue**: Cannot log in with correct credentials
**Solutions**:
- Clear browser cache and cookies
- Try incognito/private browsing mode
- Check if Caps Lock is on
- Contact administrator for password reset

#### Quiz Loading Issues
**Issue**: Quiz doesn't load or shows errors
**Solutions**:
- Refresh the page
- Check internet connection
- Disable browser extensions
- Try a different browser

#### Timer Problems
**Issue**: Timer not working correctly
**Solutions**:
- Ensure stable internet connection
- Refresh the page to resync
- Check if JavaScript is enabled
- Contact support if persistent

#### Image Display Issues
**Issue**: Questions or options not showing as images
**Solutions**:
- Check internet connection
- Clear browser cache
- Disable ad blockers
- Try a different browser

### Performance Issues

#### Slow Loading
**Causes & Solutions**:
- **Slow internet**: Use wired connection if possible
- **Server overload**: Try again during off-peak hours
- **Browser issues**: Clear cache, restart browser
- **Device performance**: Close other applications

#### Connection Problems
**Symptoms**: Red connection indicator, sync issues
**Solutions**:
- Check internet stability
- Refresh the page
- Switch to a different network
- Contact technical support

### Browser Compatibility

#### Recommended Browsers
- **Chrome 90+** (Recommended)
- **Firefox 88+**
- **Safari 14+**
- **Edge 90+**

#### Unsupported Features
- **Internet Explorer** (not supported)
- **Very old browser versions**
- **Browsers with JavaScript disabled**

### Getting Help

#### Self-Help Resources
1. **Check this manual** for common solutions
2. **Try basic troubleshooting** (refresh, clear cache)
3. **Test with different browser/device**

#### Contact Support
- **Email**: support@yourquizplatform.com
- **Include**: Error messages, browser version, steps to reproduce
- **Response time**: 24-48 hours

#### Emergency Issues
- **Quiz in progress**: Contact administrator immediately
- **System-wide problems**: Check status page
- **Data loss concerns**: Contact support with details

---

## 📋 Quick Reference

### Keyboard Shortcuts (Admin)
- **Ctrl+N**: New quiz
- **Ctrl+S**: Save current work
- **Ctrl+D**: Dashboard
- **Ctrl+U**: User management

### Important URLs
- **Dashboard**: `/dashboard`
- **Admin Panel**: `/admin`
- **User Profile**: `/profile`
- **Quiz Results**: `/results`

### Default Settings
- **Quiz Duration**: 60 minutes
- **Per Question Time**: 30 seconds
- **Max File Upload**: 16MB
- **Session Timeout**: 2 hours

---

**Note**: This manual covers the current version of the Quiz Platform. Features and interfaces may be updated in future versions.

