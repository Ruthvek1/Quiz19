# Quiz Platform Deployment Guide

## 🚀 Quick Start

### Prerequisites
- Python 3.11+ 
- Node.js 20+
- Git

### Local Development Setup

1. **Clone the project**
```bash
git clone <repository-url>
cd quiz-platform
```

2. **Backend Setup**
```bash
cd quiz-backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
python src/main.py
```

3. **Frontend Setup**
```bash
cd quiz-frontend
pnpm install  # or npm install
pnpm run dev --host  # or npm run dev
```

4. **Access the Application**
- Frontend: http://localhost:5173 (or 5174)
- Backend API: http://localhost:5001
- Admin Login: admin / admin123

## 🌐 Production Deployment

### Option 1: Cloud Deployment (Recommended)

#### Backend Deployment (Heroku/Railway/DigitalOcean)

1. **Prepare for deployment**
```bash
cd quiz-backend
pip freeze > requirements.txt
```

2. **Create Procfile**
```
web: python src/main.py
```

3. **Environment Variables**
```
FLASK_ENV=production
SECRET_KEY=your-secret-key-here
DATABASE_URL=postgresql://user:pass@host:port/dbname
```

4. **Deploy to Heroku**
```bash
heroku create your-quiz-app-backend
heroku config:set SECRET_KEY=your-secret-key
heroku addons:create heroku-postgresql:hobby-dev
git push heroku main
```

#### Frontend Deployment (Netlify/Vercel)

1. **Build the frontend**
```bash
cd quiz-frontend
pnpm run build
```

2. **Deploy to Netlify**
```bash
npm install -g netlify-cli
netlify deploy --prod --dir=dist
```

3. **Environment Variables**
```
VITE_API_BASE_URL=https://your-backend-url.herokuapp.com
```

### Option 2: VPS Deployment

#### Server Setup (Ubuntu 22.04)

1. **Install dependencies**
```bash
sudo apt update
sudo apt install python3 python3-pip nodejs npm nginx
sudo npm install -g pnpm
```

2. **Setup application**
```bash
git clone <repository-url>
cd quiz-platform

# Backend
cd quiz-backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Frontend
cd ../quiz-frontend
pnpm install
pnpm run build
```

3. **Configure Nginx**
```nginx
server {
    listen 80;
    server_name your-domain.com;

    # Frontend
    location / {
        root /path/to/quiz-platform/quiz-frontend/dist;
        try_files $uri $uri/ /index.html;
    }

    # Backend API
    location /api {
        proxy_pass http://localhost:5001;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    # WebSocket
    location /socket.io {
        proxy_pass http://localhost:5001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
```

4. **Setup systemd service**
```ini
[Unit]
Description=Quiz Platform Backend
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/path/to/quiz-platform/quiz-backend
Environment=PATH=/path/to/quiz-platform/quiz-backend/venv/bin
ExecStart=/path/to/quiz-platform/quiz-backend/venv/bin/python src/main.py
Restart=always

[Install]
WantedBy=multi-user.target
```

## 🔧 Configuration

### Backend Configuration

**Environment Variables:**
```bash
# Required
SECRET_KEY=your-secret-key-here
FLASK_ENV=production

# Database (SQLite default, PostgreSQL recommended for production)
DATABASE_URL=sqlite:///quiz_platform.db
# or
DATABASE_URL=postgresql://user:pass@host:port/dbname

# Optional
CORS_ORIGINS=https://your-frontend-domain.com
MAX_CONTENT_LENGTH=16777216  # 16MB for file uploads
```

**Database Migration:**
```bash
# The app automatically creates tables on first run
# For production, consider using Flask-Migrate
python src/main.py  # Creates tables automatically
```

### Frontend Configuration

**Environment Variables (.env):**
```bash
VITE_API_BASE_URL=http://localhost:5001  # Development
# or
VITE_API_BASE_URL=https://your-backend-domain.com  # Production
```

## 📊 Scaling for 200+ Users

### Database Optimization

1. **Use PostgreSQL in production**
```bash
pip install psycopg2-binary
```

2. **Connection pooling**
```python
# Add to main.py
from sqlalchemy import create_engine
from sqlalchemy.pool import QueuePool

engine = create_engine(
    DATABASE_URL,
    poolclass=QueuePool,
    pool_size=20,
    max_overflow=30
)
```

### WebSocket Scaling

1. **Use Redis for session storage**
```bash
pip install redis flask-session
```

2. **Configure Redis**
```python
import redis
from flask_session import Session

app.config['SESSION_TYPE'] = 'redis'
app.config['SESSION_REDIS'] = redis.from_url('redis://localhost:6379')
Session(app)
```

### Load Balancing

1. **Multiple backend instances**
```bash
# Run multiple instances on different ports
python src/main.py --port 5001
python src/main.py --port 5002
python src/main.py --port 5003
```

2. **Nginx load balancing**
```nginx
upstream backend {
    server localhost:5001;
    server localhost:5002;
    server localhost:5003;
}

location /api {
    proxy_pass http://backend;
}
```

## 🛡️ Security Configuration

### SSL/HTTPS Setup

1. **Let's Encrypt with Certbot**
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

2. **Force HTTPS in Nginx**
```nginx
server {
    listen 80;
    server_name your-domain.com;
    return 301 https://$server_name$request_uri;
}
```

### Security Headers

```nginx
add_header X-Frame-Options DENY;
add_header X-Content-Type-Options nosniff;
add_header X-XSS-Protection "1; mode=block";
add_header Strict-Transport-Security "max-age=31536000; includeSubDomains";
```

## 📈 Monitoring & Maintenance

### Health Checks

1. **Backend health endpoint**
```python
@app.route('/health')
def health_check():
    return {'status': 'healthy', 'timestamp': datetime.utcnow()}
```

2. **Monitoring script**
```bash
#!/bin/bash
curl -f http://localhost:5001/health || systemctl restart quiz-backend
```

### Log Management

1. **Configure logging**
```python
import logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s',
    handlers=[
        logging.FileHandler('quiz_platform.log'),
        logging.StreamHandler()
    ]
)
```

2. **Log rotation**
```bash
sudo nano /etc/logrotate.d/quiz-platform
```

### Backup Strategy

1. **Database backup**
```bash
# PostgreSQL
pg_dump quiz_platform > backup_$(date +%Y%m%d).sql

# SQLite
cp quiz_platform.db backup_$(date +%Y%m%d).db
```

2. **Automated backups**
```bash
# Add to crontab
0 2 * * * /path/to/backup-script.sh
```

## 🔍 Troubleshooting

### Common Issues

1. **CORS errors**
   - Check CORS_ORIGINS environment variable
   - Ensure frontend URL is whitelisted

2. **WebSocket connection fails**
   - Check firewall settings
   - Verify proxy configuration for WebSocket upgrade

3. **Image generation fails**
   - Install required fonts: `sudo apt install fonts-dejavu`
   - Check PIL/Pillow installation

4. **Database connection errors**
   - Verify DATABASE_URL format
   - Check database server status
   - Ensure connection limits aren't exceeded

### Performance Issues

1. **Slow API responses**
   - Enable database query logging
   - Add database indexes
   - Implement caching

2. **High memory usage**
   - Monitor with `htop` or `ps`
   - Implement connection pooling
   - Optimize image generation

## 📞 Support

For deployment issues or questions:
1. Check the troubleshooting section above
2. Review application logs
3. Verify all environment variables are set
4. Test with minimal configuration first

---

**Note**: This deployment guide covers the most common scenarios. Adjust configurations based on your specific infrastructure and requirements.

